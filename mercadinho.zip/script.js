// Doces animados na entrada
const docesEmojis = ["🍭", "🍬", "🍫", "🍩", "🧁"];
const docesContainer = document.getElementById("doces");

function criarDoce() {
    const doce = document.createElement("div");
    doce.classList.add("docinho");
    doce.style.left = Math.random() * window.innerWidth + "px";
    doce.style.animationDuration = (3 + Math.random() * 3) + "s";
    doce.textContent = docesEmojis[Math.floor(Math.random() * docesEmojis.length)];
    docesContainer.appendChild(doce);
    setTimeout(() => {
        if (docesContainer.contains(doce)) docesContainer.removeChild(doce);
    }, 6000);
}
setInterval(criarDoce, 300);

// Botão de entrada no mercado
document.getElementById("btnEntrar").addEventListener("click", () => {
    document.getElementById("entrada").style.display = "none";
    document.getElementById("mercado").style.display = "block";
});

// Lista inicial de produtos (com doces, alimentos e bebidas)
let produtos = [
    { id: 1, nome: "🍚 Arroz 5kg", preco: 25.50 },
    { id: 2, nome: "🫘 Feijão Carioca 1kg", preco: 8.90 },
    { id: 3, nome: "🛢️ Óleo de Soja 900ml", preco: 7.50 },
    { id: 4, nome: "🍬 Bala Sortida 100g", preco: 3.50 },
    { id: 5, nome: "🍫 Chocolate Ao Leite 90g", preco: 4.50 },
    { id: 6, nome: "🧁 Cupcake Doce", preco: 5.00 },
    { id: 7, nome: "🥛 Leite UHT 1L", preco: 6.00 },
    { id: 8, nome: "🍝 Macarrão Espaguete 500g", preco: 3.90 },
    { id: 9, nome: "☕ Café Torrado 500g", preco: 12.50 },
    { id: 10, nome: "🍬 Pirulito 1 unidade", preco: 1.50 },
    { id: 11, nome: "🍩 Donut Recheado", preco: 4.20 },
    { id: 12, nome: "🧈 Margarina 250g", preco: 4.00 },
    { id: 13, nome: "🍞 Pão de Forma 500g", preco: 7.00 },
    { id: 14, nome: "🥤 Refrigerante Cola 2L", preco: 9.50 },
    { id: 15, nome: "🍊 Suco de Laranja 1L", preco: 6.80 },
    { id: 16, nome: "🍲 Massa de Lasanha 500g", preco: 5.50 },
    { id: 17, nome: "🍭 Pirulito Gigante", preco: 2.50 },
    { id: 18, nome: "🍬 Jujuba Sortida 50g", preco: 3.00 }
];

// Carrinho
let carrinho = [];
let mostrandoMais = false;
const produtosPorPagina = 5;

// Função carregar produtos
function carregarProdutos() {
    const tabela = document.getElementById("tabelaProdutos");
    tabela.innerHTML = "";
    const fim = mostrandoMais ? produtos.length : produtosPorPagina;
    const lista = produtos.slice(0, fim);

    lista.forEach(p => {
        const tr = document.createElement("tr");
        tr.innerHTML = `
            <td>${p.id}</td>
            <td>${p.nome}</td>
            <td>R$ ${p.preco.toFixed(2)}</td>
            <td>∞</td>
            <td><button onclick="adicionarCarrinho(${p.id})">Adicionar ao carrinho</button></td>
        `;
        tabela.appendChild(tr);
    });

    document.getElementById("btnMaisMenos").textContent = mostrandoMais
        ? "Menos produtos meus clientes"
        : "Mais produtos meus clientes";
}

// Botão Mais/Menos
document.getElementById("btnMaisMenos").addEventListener("click", () => {
    mostrandoMais = !mostrandoMais;
    carregarProdutos();
});

carregarProdutos(); // Inicializar tabela

// Adicionar ao carrinho
function adicionarCarrinho(id) {
    const produto = produtos.find(p => p.id === id);
    if (!produto) return;

    const item = carrinho.find(p => p.id === id);
    if (item) item.quantidadeCarrinho += 1;
    else carrinho.push({ ...produto, quantidadeCarrinho: 1 });

    atualizarCarrinho();
}

// Atualizar carrinho
function atualizarCarrinho() {
    const lista = document.getElementById("listaCarrinho");
    const totalEl = document.getElementById("totalCarrinho");
    lista.innerHTML = "";

    let total = 0;
    carrinho.forEach(item => {
        lista.innerHTML += `<li>${item.nome} - R$ ${item.preco.toFixed(2)} x ${item.quantidadeCarrinho}</li>`;
        total += item.preco * item.quantidadeCarrinho;
    });

    totalEl.textContent = `Total: R$ ${total.toFixed(2)}`;
}

// Limpar carrinho
document.getElementById("btnLimpar").addEventListener("click", () => {
    carrinho = [];
    atualizarCarrinho();
});

// Finalizar compra
document.getElementById("btnFinalizar").addEventListener("click", () => {
    if (carrinho.length === 0) {
        alert("Seu carrinho está vazio!");
        return;
    }

    document.getElementById("caixa").style.display = "block";

    let resumo = "<ul>";
    let total = 0;
    carrinho.forEach(item => {
        resumo += `<li>${item.nome} - ${item.quantidadeCarrinho} x R$ ${item.preco.toFixed(2)}</li>`;
        total += item.preco * item.quantidadeCarrinho;
    });
    resumo += `</ul><p>Total a pagar: R$ ${total.toFixed(2)}</p>`;
    document.getElementById("resumoPagamento").innerHTML = resumo;
    document.getElementById("mensagemFinal").innerHTML =
        "Já comprou tudo que quis? Que bom! Escolha a forma de pagamento:";
});

// Pagamento
function pagar(forma) {
    let formaPagamento = forma === "dinheiro"
        ? "Dinheiro 💵"
        : forma === "debito"
        ? "Cartão Débito 💳"
        : "Cartão Crédito 💳";

    document.getElementById("mensagemFinal").innerHTML =
        `Pagamento confirmado via ${formaPagamento}.<br>Todos os produtos foram pagos. Tenha um ótimo dia! 🛒😊`;

    carrinho = [];
    atualizarCarrinho();
}
